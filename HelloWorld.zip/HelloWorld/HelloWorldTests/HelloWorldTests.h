//
//  HelloWorldTests.h
//  HelloWorldTests
//
//  Created by Ifrit on 1/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface HelloWorldTests : SenTestCase

@end
